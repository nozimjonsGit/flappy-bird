using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Player : MonoBehaviour
{
    public Sprite[] sprites;
    public float speed = 5.0f;//control the speed
    private Rigidbody2D rb;
    public bool isDead = false;

    private SpriteRenderer spriteRenderer;

    private int spriteIndex;

     // Reference to the GameManager to access audio clips
    private GameManager gameManager;

    void Start()
    {
        //get rigibody2d Component of the BirdbBek
        rb = GetComponent<Rigidbody2D>();
        gameManager = FindObjectOfType<GameManager>();
        InvokeRepeating(nameof(AnimateSprite), 0.15f, 0.15f);
    }

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        //GetMouseButtonDown(0) --> left side mouse button pressed down
        if(Input.GetMouseButtonDown(0)){
            rb.velocity = Vector2.up * speed;
            gameManager.PlayAudio(gameManager.wingClip);
        }
    }

    private void OnCollisionEnter2D(Collision2D other){
        isDead = true;
        rb.velocity = Vector2.zero; // Stop the bird's movement
    }

    private void AnimateSprite()
    {
        spriteIndex++;

        if (spriteIndex >= sprites.Length) {
            spriteIndex = 0;
        }

        if (spriteIndex < sprites.Length && spriteIndex >= 0) {
            spriteRenderer.sprite = sprites[spriteIndex];
        }
    }
}
