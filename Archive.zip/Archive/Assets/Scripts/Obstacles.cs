using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacles : MonoBehaviour
{
    public float speed = 1.0f;
    // Update is called once per frame
    private GameManager gameManager;  
    private GameObject player;
    private bool hasScored = false; 

     private void Start()
    {
        gameManager = FindObjectOfType<GameManager>();  // Find the GameManager in the scene
        player = GameObject.FindGameObjectWithTag("Player");
    }

    private void FixedUpdate()
    {
        //since our Transform Component is by default set to Vector3, we cannot use Vector2.left to be assigned to 
        //transform.position
        transform.position += ((Vector3.left * speed) * Time.deltaTime);

        // Check if the bird has passed the obstacle
       if (!hasScored && player != null && transform.position.x < player.transform.position.x)
        {
            hasScored = true;
            gameManager.IncreaseScore();  // Increase the score when the bird passes the obstacle
        }
    }
}
