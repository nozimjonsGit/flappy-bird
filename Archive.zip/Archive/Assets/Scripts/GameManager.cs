using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public GameObject startBtn;
    public Player birdBek;

    public Image countdownImage1; 
    public Image countdownImage2; 
    public Image countdownImage3;

    public Text scoreText; 
    public int score = 0;  

    public Image gameOverImg;
    public float timerBack = 3;

    // Audio clips
    public AudioClip dieClip;
    public AudioClip hitClip;
    public AudioClip pointClip;
    public AudioClip swooshClip;
    public AudioClip wingClip;

    private AudioSource audioSource;

    public void Start(){
        UpdateScoreText();
        gameOverImg.gameObject.SetActive(false);
        countdownImage1.gameObject.SetActive(false);
        countdownImage2.gameObject.SetActive(false);
        countdownImage3.gameObject.SetActive(false);
        Time.timeScale = 0f;

         // Get the AudioSource component
        audioSource = GetComponent<AudioSource>();
    }

    private void Update(){
        if(birdBek.isDead){
            GameOver();
            UpdateCountdownImages();
            gameOverImg.gameObject.SetActive(true);

            if (!audioSource.isPlaying)
            {
                PlayAudio(dieClip); 
            }

            timerBack -= Time.unscaledDeltaTime;//start counting back
        }

        if (timerBack < 0) {
            PlayAudio(swooshClip); 
            RestartGame();
        }
    }

    private void UpdateCountdownImages()
    {
        // Determine which image to show based on the timer
        if (timerBack > 3)
        {
            countdownImage3.gameObject.SetActive(true); // Show 3
            countdownImage2.gameObject.SetActive(false);
            countdownImage1.gameObject.SetActive(false);
        }
        else if (timerBack > 2)
        {
            countdownImage3.gameObject.SetActive(false);
            countdownImage2.gameObject.SetActive(true); // Show 2
            countdownImage1.gameObject.SetActive(false);
        }
        else if (timerBack > 1)
        {
            countdownImage3.gameObject.SetActive(false);
            countdownImage2.gameObject.SetActive(false);
            countdownImage1.gameObject.SetActive(true); // Show 1
        }
        else
        {
            countdownImage3.gameObject.SetActive(false);
            countdownImage2.gameObject.SetActive(false);
            countdownImage1.gameObject.SetActive(false); // Hide all images when timer reaches 0
        }
    }

    public void StartGame(){
        startBtn.SetActive(false);
        Time.timeScale = 1;
        PlayAudio(swooshClip);
    }
    public void GameOver() {
        PlayAudio(hitClip);
        Time.timeScale = 0;
    }
    public void RestartGame(){
        EditorSceneManager.LoadScene(0);
    }

    public void IncreaseScore()
    {
        score++;  
        PlayAudio(pointClip); 
        UpdateScoreText();  
    }

    private void UpdateScoreText()
    {
        scoreText.text = score.ToString(); 
    }

    public void PlayAudio(AudioClip clip)
    {
        if (clip != null)
        {
            audioSource.PlayOneShot(clip);  // Play the audio clip once
        }
    }
}
